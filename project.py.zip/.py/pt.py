from tkinter import *
import tkinter.messagebox as msg
import random

root = Tk()
root.title("RETAIL BILLING SYSTEM")
root.geometry("1350x700")
root.config(bg="gray45")
name_txt = Entry(customer_frame, width=20, font="arial 13", bd=5, relief=SUNKEN)
name_txt.grid(row=0, column=1, pady=5, padx=10)

phn_txt = Entry(customer_frame, width=20, font="arial 13", bd=5, relief=SUNKEN)
phn_txt.grid(row=0, column=3, pady=5, padx=10)

bill_txt = Entry(customer_frame, width=20, font="arial 13", bd=5, relief=SUNKEN)
bill_txt.grid(row=0, column=5, pady=5, padx=10)

Label(customer_frame, text="Name", bg="gray20", fg="white", font=("times new roman", 15, "bold")).grid(row=0, column=0, padx=20, pady=5)
Label(customer_frame, text="Phone Number", bg="gray20", fg="white", font=("times new roman", 15, "bold")).grid(row=0, column=2, padx=20, pady=5)
Label(customer_frame, text="Bill Number", bg="gray20", fg="white", font=("times new roman", 15, "bold")).grid(row=0, column=4, padx=20, pady=5)
Button(customer_frame, text="Search", width=10, bd=7, font="arial 12 bold").grid(row=0, column=6, padx=10, pady=5)


item_entries = {}

def create_item_frame(title, items, x):
    frame = LabelFrame(root, text=title, font=("times new roman", 15, "bold"),
                       fg="gold", bg="gray20", bd=10, relief=GROOVE)
    frame.place(x=x, y=170, width=330, height=380)
    entries = {}
    for i, item in enumerate(items):
        Label(frame, text=item, font=("times new roman", 14, "bold"), bg="gray20", fg="white").grid(row=i, column=0, padx=8, pady=5, sticky="w")
        e = Entry(frame, width=9, font="arial 12", bd=5, relief=SUNKEN)
        e.grid(row=i, column=1, padx=10, pady=5)
        e.insert(0, "0")
        entries[item] = e
        item_entries[item] = e
    return entries

create_item_frame("Appetizers", appetizers, 0)
create_item_frame("Main Course", main_course, 330)
create_item_frame("Beverages", beverages, 660)


bill_frame = Frame(root, bd=10, relief=GROOVE)
bill_frame.place(x=1000, y=170, width=450, height=380)
Label(bill_frame, text="Bill Area", font="arial 15 bold", bd=7, relief=GROOVE).pack(fill=X)
scroll_y = Scrollbar(bill_frame, orient=VERTICAL)
txtarea = Text(bill_frame, yscrollcommand=scroll_y.set)
scroll_y.pack(side=RIGHT, fill=Y)
scroll_y.config(command=txtarea.yview)
txtarea.pack(fill=BOTH, expand=1)


menu_frame = LabelFrame(root, text="Bill Menu", font=("times new roman", 15, "bold"),
                        fg="gold", bg="gray20", bd=10, relief=GROOVE)
menu_frame.place(x=0, y=550, relwidth=1, height=200)


price_vars = [StringVar(value="0") for _ in range(6)]
labels = ["Appetizer Price", "Main Course Price", "Beverage Price", "Appetizer Tax", "Main Course Tax", "Beverage Tax"]

for i, label in enumerate(labels):
    Label(menu_frame, text=label, font="arial 14 bold", bg="gray20", fg="white").grid(row=i//3, column=(i%3)*2, padx=10, pady=10, sticky="w")
    Entry(menu_frame, textvariable=price_vars[i], width=18, font='arial 10 bold', bd=5, relief=SUNKEN).grid(row=i//3, column=(i%3)*2+1, padx=10, pady=10)


def calculate_total():
    appetizer_total = sum(int(item_entries[item].get()) * prices[item] for item in appetizers)
    main_total = sum(int(item_entries[item].get()) * prices[item] for item in main_course)
    beverage_total = sum(int(item_entries[item].get()) * prices[item] for item in beverages)

    appetizer_tax = round(appetizer_total * tax_rate, 2)
    main_tax = round(main_total * tax_rate, 2)
    beverage_tax = round(beverage_total * tax_rate, 2)

    price_vars[0].set(f"{appetizer_total:.2f}")
    price_vars[1].set(f"{main_total:.2f}")
    price_vars[2].set(f"{beverage_total:.2f}")
    price_vars[3].set(f"{appetizer_tax:.2f}")
    price_vars[4].set(f"{main_tax:.2f}")
    price_vars[5].set(f"{beverage_tax:.2f}")

def generate_bill():
    txtarea.delete('1.0', END)
    txtarea.insert(END, "\tWelcome to Our Restaurant\n")
    txtarea.insert(END, f"\nBill No: {random.randint(1000,9999)}")
    txtarea.insert(END, f"\nCustomer Name: {name_txt.get()}")
    txtarea.insert(END, f"\nPhone No: {phn_txt.get()}")
    txtarea.insert(END, "\n=====================================")
    txtarea.insert(END, "\nItem\t\tQty\tPrice")

    total = 0
    for item in appetizers + main_course + beverages:
        qty = int(item_entries[item].get())
        if qty > 0:
            cost = qty * prices[item]
            txtarea.insert(END, f"\n{item:16}\t{qty}\t{cost}")
            total += cost

    tax_total = sum(float(var.get()) for var in price_vars[3:])
    grand_total = total + tax_total
    txtarea.insert(END, "\n=====================================")
    txtarea.insert(END, f"\nTax:\t\t\t{tax_total:.2f}")
    txtarea.insert(END, f"\nTotal Amount:\t\t{grand_total:.2f}")
    txtarea.insert(END, "\n=====================================")


btn_frame = Frame(menu_frame, bd=7, relief=GROOVE, bg="gray20")
btn_frame.place(x=1000, width=520, height=95)

Button(btn_frame, text="Total", bg="black", fg="white", bd=5, width=9, font="arial 13 bold", command=calculate_total).grid(row=0, column=2, padx=10, pady=15)
Button(btn_frame, text="Bill", bg="black", fg="white", bd=5, width=9, font="arial 13 bold", command=generate_bill).grid(row=0, column=3, padx=10, pady=15)
Button(btn_frame, text="Email", bg="black", fg="white", bd=5, width=9, font="arial 13 bold").grid(row=0, column=4, padx=10, pady=15)
Button(btn_frame, text="Print", bg="black", fg="white", bd=5, width=9, font="arial 13 bold").grid(row=0, column=5, padx=10, pady=10)

root.mainloop()